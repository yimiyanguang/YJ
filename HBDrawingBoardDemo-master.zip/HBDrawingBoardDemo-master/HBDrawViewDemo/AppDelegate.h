//
//  AppDelegate.h
//  HBDrawViewDemo
//
//  Created by 伍宏彬 on 15/11/11.
//  Copyright © 2015年 伍宏彬. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

